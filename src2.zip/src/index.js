import React from "react";
import Reactdom from "react-dom";
import App from "./App";
import "./index.css";
import "bootstrap/dist/css/bootstrap.css";

Reactdom.render(<App />, document.getElementById("root"));
